import { useEffect, useMemo, useState } from "react";
import { Award, Banknote, Clapperboard, Film, Star, Trophy, Users, TrendingUp, CalendarDays, Plus, Play, Search, Crown } from "lucide-react";

type StarProfile = { name: string; industry: string; role: "Actor" | "Actress"; fee: number; fame: number };
type Movie = { id: number; title: string; language: string; genre: string; actor: string; actress: string; budget: number; marketing: number; status: "In production" | "Released"; gross?: number; opening?: number; rating?: number };
type Save = { cash: number; fame: number; level: number; week: number; movies: Movie[]; awards: string[] };

const talent: StarProfile[] = [
  {name:"Vijay",industry:"Tamil",role:"Actor",fee:80,fame:98},
  {name:"Rajinikanth",industry:"Tamil",role:"Actor",fee:90,fame:99},
  {name:"Kamal Haasan",industry:"Tamil",role:"Actor",fee:75,fame:96},
  {name:"Ajith Kumar",industry:"Tamil",role:"Actor",fee:70,fame:94},
  {name:"Suriya",industry:"Tamil",role:"Actor",fee:55,fame:91},
  {name:"Dhanush",industry:"Tamil",role:"Actor",fee:45,fame:89},
  {name:"Vijay Sethupathi",industry:"Tamil",role:"Actor",fee:38,fame:90},
  {name:"Nayanthara",industry:"Tamil",role:"Actress",fee:38,fame:93},
  {name:"Trisha",industry:"Tamil",role:"Actress",fee:32,fame:91},
  {name:"Keerthy Suresh",industry:"Tamil",role:"Actress",fee:27,fame:86},
  {name:"Prabhas",industry:"Telugu",role:"Actor",fee:95,fame:99},
  {name:"Allu Arjun",industry:"Telugu",role:"Actor",fee:85,fame:98},
  {name:"Mahesh Babu",industry:"Telugu",role:"Actor",fee:75,fame:96},
  {name:"Jr NTR",industry:"Telugu",role:"Actor",fee:75,fame:96},
  {name:"Ram Charan",industry:"Telugu",role:"Actor",fee:75,fame:95},
  {name:"Samantha Ruth Prabhu",industry:"Telugu",role:"Actress",fee:35,fame:90},
  {name:"Rashmika Mandanna",industry:"Telugu",role:"Actress",fee:32,fame:92},
  {name:"Sai Pallavi",industry:"Telugu",role:"Actress",fee:28,fame:89},
  {name:"Mohanlal",industry:"Malayalam",role:"Actor",fee:55,fame:97},
  {name:"Mammootty",industry:"Malayalam",role:"Actor",fee:55,fame:96},
  {name:"Fahadh Faasil",industry:"Malayalam",role:"Actor",fee:35,fame:91},
  {name:"Dulquer Salmaan",industry:"Malayalam",role:"Actor",fee:42,fame:91},
  {name:"Prithviraj Sukumaran",industry:"Malayalam",role:"Actor",fee:38,fame:88},
  {name:"Manju Warrier",industry:"Malayalam",role:"Actress",fee:22,fame:85},
  {name:"Aishwarya Lekshmi",industry:"Malayalam",role:"Actress",fee:18,fame:80},
  {name:"Yash",industry:"Kannada",role:"Actor",fee:80,fame:97},
  {name:"Sudeep",industry:"Kannada",role:"Actor",fee:38,fame:88},
  {name:"Rakshit Shetty",industry:"Kannada",role:"Actor",fee:25,fame:84},
  {name:"Rachita Ram",industry:"Kannada",role:"Actress",fee:15,fame:78},
  {name:"Ramya",industry:"Kannada",role:"Actress",fee:20,fame:83}
];
const initial: Save = {cash:500,fame:12,level:1,week:1,movies:[],awards:[]};
const genres = ["Action","Drama","Romance","Thriller","Comedy","Fantasy"];
const money = (n:number) => `₹${n.toFixed(1)} Cr`;
const star = (name:string) => talent.find(t=>t.name===name)!;
const load = ():Save => { try { return {...initial,...JSON.parse(localStorage.getItem("reeltycoon-save") || "{}")}; } catch { return initial; } };

export default function App() {
  const [save,setSave] = useState<Save>(load);
  const [tab,setTab] = useState("Studio");
  const [showForm,setShowForm] = useState(false);
  const [title,setTitle] = useState("");
  const [language,setLanguage] = useState("Tamil");
  const [genre,setGenre] = useState("Action");
  const [actor,setActor] = useState("Vijay");
  const [actress,setActress] = useState("Nayanthara");
  const [budget,setBudget] = useState(100);
  const [marketing,setMarketing] = useState(15);
  const [query,setQuery] = useState("");
  const [industry,setIndustry] = useState("All");
  const [role,setRole] = useState("All");
  const [message,setMessage] = useState("Welcome to your cinema empire.");
  const cost = budget + marketing + star(actor).fee + star(actress).fee;
  const released = save.movies.filter(m=>m.status==="Released");
  const gross = released.reduce((n,m)=>n+(m.gross||0),0);
  const estimate = useMemo(()=>Math.round((budget*1.55+marketing*2+(star(actor).fame+star(actress).fame)*1.15)*10)/10,[budget,marketing,actor,actress]);
  const cast = talent.filter(t=>(industry==="All"||t.industry===industry)&&(role==="All"||t.role===role)&&t.name.toLowerCase().includes(query.toLowerCase()));
  useEffect(()=>{localStorage.setItem("reeltycoon-save",JSON.stringify(save));},[save]);
  function createMovie(e:React.FormEvent) {
    e.preventDefault();
    if(!title.trim()) return;
    if(cost>save.cash){setMessage("Not enough funds. Reduce the budget or advance a week.");return;}
    const movie:Movie={id:Date.now(),title:title.trim(),language,genre,actor,actress,budget,marketing,status:"In production"};
    setSave(s=>({...s,cash:s.cash-cost,movies:[movie,...s.movies]}));
    setShowForm(false);setTitle("");setMessage(`${movie.title} is now in production.`);
  }
  function release(movie:Movie) {
    const chemistry=(star(movie.actor).fame+star(movie.actress).fame)/2;
    const boost=movie.genre==="Action"?1.18:movie.genre==="Drama"?1.08:1.02;
    const quality=Math.min(1.45,Math.max(.62,(movie.budget/100)*.42+(movie.marketing/30)*.28+(chemistry/100)*.48));
    const opening=Math.max(4,Math.round((movie.budget*.12+movie.marketing*.55+chemistry*.12)*boost*10)/10);
    const total=Math.round((movie.budget*1.05+movie.marketing*1.6+chemistry*1.8)*quality*boost*10)/10;
    const rating=Math.min(9.8,Math.round((5.2+quality*2.2+chemistry/100*1.1+movie.marketing/100)*10)/10);
    setSave(s=>({...s,cash:s.cash+total,fame:Math.min(100,s.fame+Math.round(rating)),week:s.week+1,level:Math.max(s.level,Math.floor((s.fame+rating)/20)+1),movies:s.movies.map(m=>m.id===movie.id?{...m,status:"Released",gross:total,opening,rating}:m),awards:rating>=8.8?[...s.awards,`${movie.title} — Audience Choice`]:s.awards}));
    setMessage(`${movie.title} released! Worldwide gross: ${money(total)}.`);
  }
  function advanceWeek(){setSave(s=>({...s,week:s.week+1,cash:s.cash+Math.max(2,s.movies.filter(m=>m.status==="Released").length*1.5)}));setMessage("New industry week: streaming and catalogue income received.");}
  function reset(){if(confirm("Reset your cinema career?")){setSave(initial);setTab("Studio");setMessage("A new production house awaits.");}}
  const tabs=["Studio","My films","Talent pool","Box office","Awards","Career"];
  const actors=talent.filter(t=>t.role==="Actor"), actresses=talent.filter(t=>t.role==="Actress");
  return <div className="layout">
    <aside className="sidebar"><div className="brand"><div className="brand-icon"><Film/></div><div>REEL<span>TYCOON</span><small>SOUTH INDIAN CINEMA</small></div></div>
      <div className="producer"><Crown/><div><b>Independent Producer</b><small>Level {save.level} · Week {save.week}</small></div></div>
      <p className="nav-title">PRODUCTION HOUSE</p>{tabs.map(t=><button key={t} className={`nav ${tab===t?"active":""}`} onClick={()=>setTab(t)}>{t}</button>)}
      <div className="sidebar-bottom"><p>Dream big. Make cinema.</p><button className="reset" onClick={reset}>Reset career</button><small>Fan-made fictional game · v1.0</small></div>
    </aside>
    <main className="main"><header><span>REELTYCOON / <b>{tab}</b></span><div className="stats"><b><Banknote size={16}/>{money(save.cash)}</b><b><Star size={16}/>{save.fame} fame</b><b><CalendarDays size={16}/>Week {save.week}</b></div></header>
      <section className="content"><div className="notice">{message}<button onClick={()=>setMessage("")}>×</button></div>
      {tab==="Studio"&&<><div className="hero"><span className="eyebrow">YOUR STORY STARTS HERE</span><h1>Lights. Camera.<br/><em>Your legacy.</em></h1><p>Build a South Indian film empire. Discover talent, produce blockbusters and rule the box office.</p><button className="gold" onClick={()=>setShowForm(true)}><Plus size={17}/> Produce a movie</button></div>
        <div className="metrics"><Metric icon={<WalletIcon/>} label="Studio balance" value={money(save.cash)}/><Metric icon={<Film/>} label="Movies produced" value={String(save.movies.length)}/><Metric icon={<TicketIcon/>} label="Worldwide gross" value={money(gross)}/><Metric icon={<TrendingUp/>} label="Career fame" value={`${save.fame}/100`}/></div>
        <Section title="Your latest projects" action={<button className="link" onClick={()=>setTab("My films")}>View all →</button>}/>
        {save.movies.length===0?<Empty title="Your first blockbuster is waiting." text="Choose your stars, set a budget and bring your first story to life." action={()=>setShowForm(true)}/>:<div className="movie-grid">{save.movies.slice(0,3).map(m=><MovieCard key={m.id} movie={m} onRelease={()=>release(m)}/>)}</div>}
      </>}
      {tab==="My films"&&<><Section title="The movie slate" action={<button className="gold" onClick={()=>setShowForm(true)}><Plus size={16}/> New production</button>}/>{save.movies.length?<div className="movie-grid">{save.movies.map(m=><MovieCard key={m.id} movie={m} onRelease={()=>release(m)}/>)}</div>:<Empty title="No films in production" text="Start by producing your first movie." action={()=>setShowForm(true)}/>}</>}
      {tab==="Talent pool"&&<><Section title="Casting directory"/><div className="filters"><label><Search size={16}/><input placeholder="Search talent..." value={query} onChange={e=>setQuery(e.target.value)}/></label><select value={industry} onChange={e=>setIndustry(e.target.value)}>{["All","Tamil","Telugu","Malayalam","Kannada"].map(x=><option>{x}</option>)}</select><select value={role} onChange={e=>setRole(e.target.value)}>{["All","Actor","Actress"].map(x=><option>{x}</option>)}</select></div><div className="talent-grid">{cast.map(t=><div className="talent-card" key={t.name}><div><b>{t.name}</b><small>{t.industry} · {t.role}</small></div><span>{money(t.fee)}<small>Game fee</small></span><strong>★ {t.fame}</strong></div>)}</div></>}
      {tab==="Box office"&&<><Section title="Box office report"/><div className="metrics"><Metric icon={<TrendingUp/>} label="Worldwide gross" value={money(gross)}/><Metric icon={<Film/>} label="Released films" value={String(released.length)}/><Metric icon={<Star/>} label="Average rating" value={released.length?(released.reduce((n,m)=>n+(m.rating||0),0)/released.length).toFixed(1)+"/10":"—"}/><Metric icon={<Banknote/>} label="Studio balance" value={money(save.cash)}/></div>{released.length?<div className="table-wrap"><table><thead><tr><th>Movie</th><th>Language</th><th>Opening</th><th>Worldwide gross</th><th>Rating</th></tr></thead><tbody>{released.map(m=><tr><td>{m.title}</td><td>{m.language}</td><td>{money(m.opening||0)}</td><td>{money(m.gross||0)}</td><td>★ {m.rating}/10</td></tr>)}</tbody></table></div>:<Empty title="The box office is waiting" text="Release your first movie to see its performance."/>}</>}
      {tab==="Awards"&&<><Section title="Awards room"/><div className="award-banner"><Trophy size={46}/><h2>Great stories deserve a standing ovation.</h2><p>Films rated 8.8 or above earn an Audience Choice award.</p></div>{save.awards.length?save.awards.map(a=><div className="award-row"><Award/>{a}</div>):<Empty title="Your trophy cabinet is empty" text="Release a critically acclaimed film to win your first award."/>}</>}
      {tab==="Career"&&<><Section title="The producer's journey"/><div className="career"><Crown size={40}/><div><small>YOUR CURRENT RANK</small><h2>{save.level>=5?"Industry Icon":save.level>=3?"Celebrated Producer":save.level>=2?"Rising Producer":"Independent Producer"}</h2><p>Level {save.level} · {save.fame} career fame</p></div><div className="progress"><b>{save.fame}/100 fame</b><div><i style={{width:`${save.fame}%`}}/></div></div></div><div className="milestones">{["Independent producer","Rising producer","Celebrated producer","Industry icon"].map((m,i)=><div className={save.level>=i+1?"unlocked":""}><b>Level {i+1} · {m}</b><span>{save.level>=i+1?"UNLOCKED":"LOCKED"}</span></div>)}</div><button className="gold" onClick={advanceWeek}><Play size={16}/> Advance week</button></>}
      <footer>REELTYCOON · Fan-made fictional game. Not affiliated with or endorsed by any actor, studio or awards body.</footer></section>
    </main>
    {showForm&&<div className="overlay"><form className="modal" onSubmit={createMovie}><div className="modal-head"><div><span className="eyebrow">GREENLIGHT A NEW PROJECT</span><h2>Produce your movie</h2></div><button type="button" onClick={()=>setShowForm(false)}>×</button></div>
      <label>Movie title<input required maxLength={50} placeholder="Enter your film title" value={title} onChange={e=>setTitle(e.target.value)}/></label>
      <div className="two"><label>Industry<select value={language} onChange={e=>setLanguage(e.target.value)}>{["Tamil","Telugu","Malayalam","Kannada"].map(x=><option>{x}</option>)}</select></label><label>Genre<select value={genre} onChange={e=>setGenre(e.target.value)}>{genres.map(x=><option>{x}</option>)}</select></label></div>
      <div className="two"><label>Lead actor<select value={actor} onChange={e=>setActor(e.target.value)}>{actors.map(t=><option>{t.name}</option>)}</select></label><label>Lead actress<select value={actress} onChange={e=>setActress(e.target.value)}>{actresses.map(t=><option>{t.name}</option>)}</select></label></div>
      <label className="range-label">Production budget <b>{money(budget)}</b><input type="range" min="20" max="250" step="5" value={budget} onChange={e=>setBudget(+e.target.value)}/></label>
      <label className="range-label">Marketing & promotions <b>{money(marketing)}</b><input type="range" min="5" max="80" step="5" value={marketing} onChange={e=>setMarketing(+e.target.value)}/></label>
      <div className="budget"><p>Star fees <b>{money(star(actor).fee+star(actress).fee)}</b></p><p className="total">Total investment <b>{money(cost)}</b></p><p>Potential box-office estimate* <b>{money(estimate)}</b></p></div><small className="fine">*Fictional game estimate. Star fees, fame and box-office values are invented for gameplay.</small>
      {cost>save.cash&&<p className="warning">You need {money(cost-save.cash)} more to greenlight this film.</p>}
      <div className="actions"><button type="button" className="secondary" onClick={()=>setShowForm(false)}>Cancel</button><button className="gold" disabled={cost>save.cash}><Clapperboard size={16}/> Greenlight film</button></div>
    </form></div>}
  </div>;
}
function Metric({icon,label,value}:{icon:React.ReactNode;label:string;value:string}){return <div className="metric"><div>{icon}</div><span>{label}</span><b>{value}</b></div>}
function Section({title,action}:{title:string;action?:React.ReactNode}){return <div className="section-title"><h2>{title}</h2>{action}</div>}
function Empty({title,text,action}:{title:string;text:string;action?:()=>void}){return <div className="empty"><Film size={32}/><h3>{title}</h3><p>{text}</p>{action&&<button className="gold" onClick={action}><Plus size={16}/> Start producing</button>}</div>}
function MovieCard({movie,onRelease}:{movie:Movie;onRelease:()=>void}){return <div className="movie-card"><div className={`poster ${movie.genre.toLowerCase()}`}><span>{movie.language.toUpperCase()} CINEMA</span><strong>{movie.title}</strong><small>{movie.genre.toUpperCase()} · REELTYCOON ORIGINAL</small></div><div className="movie-info"><b>{movie.title}</b><small>Starring {movie.actor} & {movie.actress}</small><p>{movie.status==="Released"?`Worldwide gross ${money(movie.gross||0)} · ★ ${movie.rating}/10`:"In production · "+money(movie.budget+movie.marketing)+" planned spend"}</p>{movie.status==="In production"&&<button className="gold" onClick={onRelease}><Play size={15}/> Release to theatres</button>}</div></div>}
function WalletIcon(){return <Banknote/>}
function TicketIcon(){return <Clapperboard/>}
