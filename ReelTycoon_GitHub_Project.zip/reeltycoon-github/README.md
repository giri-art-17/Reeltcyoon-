# ReelTycoon — South Indian Cinema Simulator

A playable React + TypeScript + Vite cinema-management game focused on Tamil, Telugu, Malayalam and Kannada film industries.

## Features

- Browse a talent directory containing real South Indian actors and actresses.
- Create films, select industry, genre and lead cast.
- Set production and marketing budgets with a live investment estimate.
- Release films to simulate opening-day collections, worldwide gross and audience ratings.
- Track the box office, earn Audience Choice awards and progress through producer levels.
- Save career progress automatically in the browser using `localStorage`.
- Responsive layout for desktop and mobile.

> **Important:** Actor and actress names refer to real public film personalities. Fees, fame scores, ratings, awards and box-office results are fictional gameplay values, not real-world data or predictions. This fan-made game is not affiliated with or endorsed by any actor, studio or awards body.

## Run locally

You need Node.js 18 or newer.

```bash
npm install
npm run dev
```

Open the local URL shown by Vite (usually http://localhost:5173).

## Build for production

```bash
npm run build
npm run preview
```

The production build is generated in the `dist/` folder.

## Upload to GitHub

1. Extract this ZIP file.
2. Open GitHub and create a new repository, for example `reeltycoon-south-indian-cinema`.
3. Select **Add file → Upload files**.
4. Upload the extracted project files and folders (including `src`, `package.json`, `index.html`, and `tsconfig.json`).
5. Commit the upload.

Do not upload `node_modules` or the generated `dist` folder.

## Game save

Progress is saved in the current browser on the current device. Clearing browser storage or switching browsers/devices may remove or not carry over the saved career.
